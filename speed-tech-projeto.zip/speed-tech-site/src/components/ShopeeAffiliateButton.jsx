import React from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart, ExternalLink } from 'lucide-react';

const ShopeeAffiliateButton = ({ 
  productId, 
  productName,
  price,
  originalPrice,
  source = 'website',
  campaign = 'general',
  variant = 'default',
  size = 'default',
  className = '',
  children,
  ...props 
}) => {
  const handleClick = () => {
    // Tracking simples
    console.log('Affiliate click:', { productId, source, campaign });
    
    // Link básico da Shopee (será melhorado depois)
    const affiliateLink = `https://shopee.com.br/search?keyword=${encodeURIComponent(productName || productId)}&affiliate_id=SPEEDTECH2025`;
    window.open(affiliateLink, '_blank', 'noopener,noreferrer');
  };

  return (
    <Button
      onClick={handleClick}
      variant={variant}
      size={size}
      className={`w-full ${className}`}
      {...props}
    >
      <ShoppingCart className="h-4 w-4 mr-2" />
      {children || 'Comprar na Shopee'}
      <ExternalLink className="h-4 w-4 ml-2" />
    </Button>
  );
};

export default ShopeeAffiliateButton;

