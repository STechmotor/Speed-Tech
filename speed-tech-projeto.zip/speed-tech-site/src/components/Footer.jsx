import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import speedTechLogo from '../assets/speed-tech-logo-variation.png';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo e descrição */}
          <div className="space-y-4">
            <img 
              src={speedTechLogo} 
              alt="Speed Tech Motor Parts" 
              className="h-12 w-auto filter brightness-0 invert"
            />
            <p className="text-gray-300 text-sm">
              Sua loja especializada em peças e acessórios automotivos. 
              Parceria oficial com Shopee para oferecer os melhores produtos 
              com qualidade e preços competitivos.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links rápidos */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-primary transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/categorias" className="text-gray-300 hover:text-primary transition-colors">
                  Categorias
                </Link>
              </li>
              <li>
                <Link to="/ofertas" className="text-gray-300 hover:text-primary transition-colors">
                  Ofertas
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-300 hover:text-primary transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/sobre" className="text-gray-300 hover:text-primary transition-colors">
                  Sobre Nós
                </Link>
              </li>
            </ul>
          </div>

          {/* Categorias */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Categorias</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/categorias/performance" className="text-gray-300 hover:text-primary transition-colors">
                  Peças de Performance
                </Link>
              </li>
              <li>
                <Link to="/categorias/acessorios" className="text-gray-300 hover:text-primary transition-colors">
                  Acessórios Automotivos
                </Link>
              </li>
              <li>
                <Link to="/categorias/ferramentas" className="text-gray-300 hover:text-primary transition-colors">
                  Ferramentas
                </Link>
              </li>
              <li>
                <Link to="/categorias/eletronicos" className="text-gray-300 hover:text-primary transition-colors">
                  Eletrônicos Automotivos
                </Link>
              </li>
              <li>
                <Link to="/categorias/cuidados" className="text-gray-300 hover:text-primary transition-colors">
                  Cuidados Automotivos
                </Link>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-gray-300 text-sm">(11) 9999-9999</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-primary" />
                <span className="text-gray-300 text-sm">contato@speedtech.com.br</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-4 w-4 text-primary mt-1" />
                <span className="text-gray-300 text-sm">
                  São Paulo, SP<br />
                  Brasil
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Linha divisória */}
        <div className="border-t border-gray-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Speed Tech Motor Parts. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacidade" className="text-gray-400 hover:text-primary text-sm transition-colors">
                Política de Privacidade
              </Link>
              <Link to="/termos" className="text-gray-400 hover:text-primary text-sm transition-colors">
                Termos de Uso
              </Link>
            </div>
          </div>
        </div>

        {/* Badge Shopee */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-2 bg-primary/10 px-4 py-2 rounded-lg">
            <span className="text-primary font-semibold text-sm">Parceiro Oficial Shopee</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

