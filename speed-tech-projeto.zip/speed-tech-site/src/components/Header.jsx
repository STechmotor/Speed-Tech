import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Search, ShoppingCart, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import speedTechLogo from '../assets/speed-tech-logo-variation.png';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Top bar */}
        <div className="flex items-center justify-between py-2 text-sm text-gray-600">
          <div className="hidden md:block">
            <span>Parceria oficial com Shopee | Frete grátis em compras acima de R$ 99</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>Atendimento: (11) 9999-9999</span>
          </div>
        </div>
        
        {/* Main header */}
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img 
              src={speedTechLogo} 
              alt="Speed Tech Motor Parts" 
              className="h-12 w-auto"
            />
          </Link>

          {/* Search bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-2xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Buscar peças e acessórios..."
                className="w-full px-4 py-2 border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button className="absolute right-0 top-0 h-full px-6 rounded-l-none">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Right side icons */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="hidden md:flex">
              <User className="h-4 w-4 mr-2" />
              Entrar
            </Button>
            <Button variant="ghost" size="sm">
              <ShoppingCart className="h-4 w-4" />
            </Button>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={toggleMenu}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className={`${isMenuOpen ? 'block' : 'hidden'} md:block pb-4`}>
          <ul className="flex flex-col md:flex-row md:space-x-8 space-y-2 md:space-y-0">
            <li>
              <Link 
                to="/" 
                className="block py-2 px-4 text-gray-700 hover:text-primary transition-colors"
              >
                Home
              </Link>
            </li>
            <li className="relative group">
              <Link 
                to="/categorias" 
                className="block py-2 px-4 text-gray-700 hover:text-primary transition-colors"
              >
                Categorias
              </Link>
              {/* Dropdown menu */}
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <Link to="/categorias/performance" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Peças de Performance
                </Link>
                <Link to="/categorias/acessorios" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Acessórios Automotivos
                </Link>
                <Link to="/categorias/ferramentas" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Ferramentas
                </Link>
                <Link to="/categorias/eletronicos" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Eletrônicos Automotivos
                </Link>
                <Link to="/categorias/cuidados" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Cuidados Automotivos
                </Link>
              </div>
            </li>
            <li>
              <Link 
                to="/ofertas" 
                className="block py-2 px-4 text-primary font-semibold hover:text-primary/80 transition-colors"
              >
                Ofertas
              </Link>
            </li>
            <li>
              <Link 
                to="/blog" 
                className="block py-2 px-4 text-gray-700 hover:text-primary transition-colors"
              >
                Blog
              </Link>
            </li>
            <li>
              <Link 
                to="/sobre" 
                className="block py-2 px-4 text-gray-700 hover:text-primary transition-colors"
              >
                Sobre
              </Link>
            </li>
            <li>
              <Link 
                to="/contato" 
                className="block py-2 px-4 text-gray-700 hover:text-primary transition-colors"
              >
                Contato
              </Link>
            </li>
          </ul>
        </nav>

        {/* Mobile search */}
        <div className={`${isMenuOpen ? 'block' : 'hidden'} md:hidden pb-4`}>
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar peças e acessórios..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <Button size="sm" className="absolute right-2 top-1/2 transform -translate-y-1/2">
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

