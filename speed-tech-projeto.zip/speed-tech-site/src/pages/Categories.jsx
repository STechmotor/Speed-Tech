import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, ShoppingCart, Filter, Grid, List } from 'lucide-react';

const Categories = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  const categories = [
    { id: 'all', name: 'Todos os Produtos', count: 2850 },
    { id: 'performance', name: 'Peças de Performance', count: 500 },
    { id: 'acessorios', name: 'Acessórios Automotivos', count: 800 },
    { id: 'ferramentas', name: 'Ferramentas', count: 300 },
    { id: 'eletronicos', name: 'Eletrônicos Automotivos', count: 400 },
    { id: 'cuidados', name: 'Cuidados Automotivos', count: 250 },
    { id: 'pneus', name: 'Pneus e Rodas', count: 600 }
  ];

  const products = [
    {
      id: 1,
      name: "Kit Suspensão Esportiva Regulável",
      price: "R$ 899,90",
      originalPrice: "R$ 1.299,90",
      image: "/api/placeholder/300/300",
      rating: 4.8,
      reviews: 156,
      discount: "31% OFF",
      category: "performance",
      shopeeLink: "https://shopee.com.br/product/123456"
    },
    {
      id: 2,
      name: "Escapamento Esportivo Inox 304",
      price: "R$ 1.299,90",
      originalPrice: "R$ 1.899,90",
      image: "/api/placeholder/300/300",
      rating: 4.9,
      reviews: 89,
      discount: "32% OFF",
      category: "performance",
      shopeeLink: "https://shopee.com.br/product/123457"
    },
    {
      id: 3,
      name: "Central Multimídia Android 10",
      price: "R$ 599,90",
      originalPrice: "R$ 899,90",
      image: "/api/placeholder/300/300",
      rating: 4.7,
      reviews: 234,
      discount: "33% OFF",
      category: "eletronicos",
      shopeeLink: "https://shopee.com.br/product/123458"
    },
    {
      id: 4,
      name: "Kit Xenon H4 8000K Completo",
      price: "R$ 199,90",
      originalPrice: "R$ 299,90",
      image: "/api/placeholder/300/300",
      rating: 4.6,
      reviews: 312,
      discount: "33% OFF",
      category: "eletronicos",
      shopeeLink: "https://shopee.com.br/product/123459"
    },
    {
      id: 5,
      name: "Cera Automotiva Premium",
      price: "R$ 89,90",
      originalPrice: "R$ 129,90",
      image: "/api/placeholder/300/300",
      rating: 4.5,
      reviews: 445,
      discount: "31% OFF",
      category: "cuidados",
      shopeeLink: "https://shopee.com.br/product/123460"
    },
    {
      id: 6,
      name: "Chave de Roda Telescópica",
      price: "R$ 149,90",
      originalPrice: "R$ 199,90",
      image: "/api/placeholder/300/300",
      rating: 4.4,
      reviews: 178,
      discount: "25% OFF",
      category: "ferramentas",
      shopeeLink: "https://shopee.com.br/product/123461"
    },
    {
      id: 7,
      name: "Tapete Automotivo Personalizado",
      price: "R$ 299,90",
      originalPrice: "R$ 399,90",
      image: "/api/placeholder/300/300",
      rating: 4.7,
      reviews: 267,
      discount: "25% OFF",
      category: "acessorios",
      shopeeLink: "https://shopee.com.br/product/123462"
    },
    {
      id: 8,
      name: "Pneu Aro 17 225/45R17",
      price: "R$ 459,90",
      originalPrice: "R$ 599,90",
      image: "/api/placeholder/300/300",
      rating: 4.8,
      reviews: 123,
      discount: "23% OFF",
      category: "pneus",
      shopeeLink: "https://shopee.com.br/product/123463"
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Categorias de Produtos</h1>
          <p className="text-gray-600 text-lg">
            Encontre as melhores peças e acessórios para seu veículo
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar - Filtros */}
          <div className="lg:w-1/4">
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filtros
                </h3>
                
                {/* Categorias */}
                <div className="mb-6">
                  <h4 className="font-medium mb-3">Categorias</h4>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <button
                        key={category.id}
                        onClick={() => setSelectedCategory(category.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                          selectedCategory === category.id
                            ? 'bg-primary text-white'
                            : 'hover:bg-gray-100'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-sm">{category.name}</span>
                          <span className="text-xs opacity-75">({category.count})</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Faixa de Preço */}
                <div className="mb-6">
                  <h4 className="font-medium mb-3">Faixa de Preço</h4>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span className="text-sm">Até R$ 100</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span className="text-sm">R$ 100 - R$ 300</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span className="text-sm">R$ 300 - R$ 500</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span className="text-sm">Acima de R$ 500</span>
                    </label>
                  </div>
                </div>

                {/* Avaliação */}
                <div>
                  <h4 className="font-medium mb-3">Avaliação</h4>
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <label key={rating} className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                            />
                          ))}
                          <span className="text-sm ml-2">& acima</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div className="flex items-center space-x-4">
                <span className="text-gray-600">
                  {filteredProducts.length} produtos encontrados
                </span>
              </div>
              
              <div className="flex items-center space-x-4">
                {/* Ordenação */}
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="popular">Mais Popular</option>
                  <option value="price-low">Menor Preço</option>
                  <option value="price-high">Maior Preço</option>
                  <option value="rating">Melhor Avaliação</option>
                  <option value="newest">Mais Recente</option>
                </select>

                {/* View Mode */}
                <div className="flex border border-gray-300 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 ${viewMode === 'grid' ? 'bg-primary text-white' : 'bg-white text-gray-600'}`}
                  >
                    <Grid className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 ${viewMode === 'list' ? 'bg-primary text-white' : 'bg-white text-gray-600'}`}
                  >
                    <List className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' 
                : 'grid-cols-1'
            }`}>
              {filteredProducts.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow group">
                  <CardContent className={`p-4 ${viewMode === 'list' ? 'flex space-x-4' : ''}`}>
                    <div className={`relative ${viewMode === 'list' ? 'w-48 flex-shrink-0' : 'mb-4'}`}>
                      <div className={`bg-gray-200 rounded-lg flex items-center justify-center ${
                        viewMode === 'list' ? 'w-full h-32' : 'w-full h-48'
                      }`}>
                        <span className="text-gray-500">Imagem do Produto</span>
                      </div>
                      <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                        {product.discount}
                      </Badge>
                    </div>
                    
                    <div className={viewMode === 'list' ? 'flex-1' : ''}>
                      <h3 className="font-semibold mb-2 line-clamp-2">{product.name}</h3>
                      <div className="flex items-center mb-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-500 ml-2">({product.reviews})</span>
                      </div>
                      <div className="mb-4">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-bold text-primary">{product.price}</span>
                          <span className="text-sm text-gray-500 line-through">{product.originalPrice}</span>
                        </div>
                      </div>
                      <Button 
                        className={viewMode === 'list' ? 'w-auto' : 'w-full'}
                        onClick={() => window.open(product.shopeeLink, '_blank')}
                      >
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Comprar na Shopee
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center mt-12">
              <div className="flex space-x-2">
                <Button variant="outline" disabled>Anterior</Button>
                <Button className="bg-primary text-white">1</Button>
                <Button variant="outline">2</Button>
                <Button variant="outline">3</Button>
                <Button variant="outline">Próximo</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Categories;

