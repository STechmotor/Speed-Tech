import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Clock, Fire, Gift, Zap, TrendingUp } from 'lucide-react';
import ShopeeAffiliateButton from '../components/ShopeeAffiliateButton';

const Offers = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const offerCategories = [
    { id: 'all', name: 'Todas as Ofertas', icon: <Gift className="h-4 w-4" /> },
    { id: 'flash', name: 'Ofertas Relâmpago', icon: <Zap className="h-4 w-4" /> },
    { id: 'daily', name: 'Ofertas do Dia', icon: <Clock className="h-4 w-4" /> },
    { id: 'trending', name: 'Mais Vendidos', icon: <TrendingUp className="h-4 w-4" /> },
    { id: 'hot', name: 'Queima de Estoque', icon: <Fire className="h-4 w-4" /> }
  ];

  const flashOffers = [
    {
      id: 'flash001',
      name: "Kit Suspensão Esportiva Regulável Premium",
      price: "R$ 699,90",
      originalPrice: "R$ 1.299,90",
      image: "/api/placeholder/300/300",
      rating: 4.9,
      reviews: 234,
      discount: "46% OFF",
      category: "flash",
      timeLeft: "02:45:30",
      sold: 89,
      stock: 150,
      features: ["Regulagem de altura", "Amortecedores premium", "Garantia 2 anos"]
    },
    {
      id: 'flash002',
      name: "Central Multimídia Android 11 com GPS",
      price: "R$ 449,90",
      originalPrice: "R$ 899,90",
      image: "/api/placeholder/300/300",
      rating: 4.8,
      reviews: 567,
      discount: "50% OFF",
      category: "flash",
      timeLeft: "01:23:15",
      sold: 156,
      stock: 200,
      features: ["Android 11", "GPS integrado", "Bluetooth 5.0"]
    }
  ];

  const dailyOffers = [
    {
      id: 'daily001',
      name: "Escapamento Esportivo Inox 304 Completo",
      price: "R$ 899,90",
      originalPrice: "R$ 1.499,90",
      image: "/api/placeholder/300/300",
      rating: 4.7,
      reviews: 123,
      discount: "40% OFF",
      category: "daily",
      features: ["Inox 304", "Som esportivo", "Fácil instalação"]
    },
    {
      id: 'daily002',
      name: "Kit Xenon H4 8000K Completo com Reator",
      price: "R$ 159,90",
      originalPrice: "R$ 299,90",
      image: "/api/placeholder/300/300",
      rating: 4.6,
      reviews: 445,
      discount: "47% OFF",
      category: "daily",
      features: ["8000K", "Reator digital", "2 anos garantia"]
    },
    {
      id: 'daily003',
      name: "Cera Automotiva Premium com Carnaúba",
      price: "R$ 69,90",
      originalPrice: "R$ 129,90",
      image: "/api/placeholder/300/300",
      rating: 4.5,
      reviews: 678,
      discount: "46% OFF",
      category: "daily",
      features: ["Carnaúba natural", "Proteção UV", "Brilho duradouro"]
    }
  ];

  const trendingOffers = [
    {
      id: 'trend001',
      name: "Pneu Aro 17 225/45R17 Performance",
      price: "R$ 389,90",
      originalPrice: "R$ 599,90",
      image: "/api/placeholder/300/300",
      rating: 4.8,
      reviews: 234,
      discount: "35% OFF",
      category: "trending",
      features: ["Alta performance", "Baixo ruído", "Economia combustível"]
    },
    {
      id: 'trend002',
      name: "Tapete Automotivo Personalizado 5 Peças",
      price: "R$ 199,90",
      originalPrice: "R$ 349,90",
      image: "/api/placeholder/300/300",
      rating: 4.7,
      reviews: 345,
      discount: "43% OFF",
      category: "trending",
      features: ["5 peças", "Personalizado", "Material premium"]
    }
  ];

  const hotOffers = [
    {
      id: 'hot001',
      name: "Chave de Roda Telescópica Profissional",
      price: "R$ 99,90",
      originalPrice: "R$ 199,90",
      image: "/api/placeholder/300/300",
      rating: 4.4,
      reviews: 178,
      discount: "50% OFF",
      category: "hot",
      features: ["Telescópica", "4 soquetes", "Cabo ergonômico"]
    }
  ];

  const allOffers = [...flashOffers, ...dailyOffers, ...trendingOffers, ...hotOffers];
  
  const filteredOffers = selectedCategory === 'all' 
    ? allOffers 
    : allOffers.filter(offer => offer.category === selectedCategory);

  const formatTimeLeft = (timeString) => {
    if (!timeString) return null;
    const [hours, minutes, seconds] = timeString.split(':');
    return `${hours}h ${minutes}m ${seconds}s`;
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-600 via-red-500 to-orange-500 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              🔥 Ofertas Imperdíveis da Shopee
            </h1>
            <p className="text-xl mb-8">
              As melhores promoções em peças e acessórios automotivos
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Badge className="bg-white text-red-600 px-4 py-2 text-lg font-semibold">
                Até 50% OFF
              </Badge>
              <Badge className="bg-yellow-400 text-red-600 px-4 py-2 text-lg font-semibold">
                Frete Grátis
              </Badge>
              <Badge className="bg-green-400 text-red-600 px-4 py-2 text-lg font-semibold">
                Garantia Shopee
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            {offerCategories.map((category) => (
              <Button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                variant={selectedCategory === category.id ? 'default' : 'outline'}
                className="flex items-center space-x-2"
              >
                {category.icon}
                <span>{category.name}</span>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Flash Offers Section */}
      {(selectedCategory === 'all' || selectedCategory === 'flash') && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 flex items-center justify-center">
                <Zap className="h-8 w-8 text-yellow-500 mr-2" />
                Ofertas Relâmpago
              </h2>
              <p className="text-gray-600 text-lg">Promoções por tempo limitado!</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {flashOffers.map((offer) => (
                <Card key={offer.id} className="overflow-hidden border-2 border-red-200 hover:border-red-400 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <Badge className="bg-red-500 text-white animate-pulse">
                        OFERTA RELÂMPAGO
                      </Badge>
                      <div className="text-right">
                        <div className="text-sm text-gray-600">Termina em:</div>
                        <div className="text-lg font-bold text-red-600">
                          {formatTimeLeft(offer.timeLeft)}
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-gray-200 rounded-lg h-48 flex items-center justify-center">
                        <span className="text-gray-500">Imagem do Produto</span>
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-semibold mb-3">{offer.name}</h3>
                        
                        <div className="flex items-center mb-3">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${i < Math.floor(offer.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-500 ml-2">({offer.reviews})</span>
                        </div>
                        
                        <div className="mb-4">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-2xl font-bold text-red-600">{offer.price}</span>
                            <span className="text-lg text-gray-500 line-through">{offer.originalPrice}</span>
                          </div>
                          <Badge className="bg-green-500 text-white">{offer.discount}</Badge>
                        </div>
                        
                        <div className="mb-4">
                          <div className="flex justify-between text-sm text-gray-600 mb-1">
                            <span>Vendidos: {offer.sold}</span>
                            <span>Estoque: {offer.stock}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-red-500 h-2 rounded-full" 
                              style={{ width: `${(offer.sold / (offer.sold + offer.stock)) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <ul className="text-sm text-gray-600 mb-4">
                          {offer.features.map((feature, index) => (
                            <li key={index} className="flex items-center">
                              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                              {feature}
                            </li>
                          ))}
                        </ul>
                        
                        <ShopeeAffiliateButton
                          productId={offer.id}
                          productName={offer.name}
                          source="offers_page"
                          campaign="flash_sale"
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Comprar Agora - Oferta Relâmpago
                        </ShopeeAffiliateButton>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Regular Offers Grid */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              {selectedCategory === 'all' ? 'Todas as Ofertas' : 
               offerCategories.find(cat => cat.id === selectedCategory)?.name}
            </h2>
            <p className="text-gray-600 text-lg">
              Produtos selecionados com os melhores preços
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOffers.filter(offer => offer.category !== 'flash').map((offer) => (
              <Card key={offer.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="relative mb-4">
                    <div className="bg-gray-200 rounded-lg h-48 flex items-center justify-center">
                      <span className="text-gray-500">Imagem do Produto</span>
                    </div>
                    <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                      {offer.discount}
                    </Badge>
                  </div>
                  
                  <h3 className="font-semibold mb-2 line-clamp-2">{offer.name}</h3>
                  
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${i < Math.floor(offer.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500 ml-2">({offer.reviews})</span>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-xl font-bold text-primary">{offer.price}</span>
                      <span className="text-sm text-gray-500 line-through">{offer.originalPrice}</span>
                    </div>
                  </div>
                  
                  <ul className="text-sm text-gray-600 mb-4">
                    {offer.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <ShopeeAffiliateButton
                    productId={offer.id}
                    productName={offer.name}
                    source="offers_page"
                    campaign={offer.category}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Não Perca Essas Ofertas!</h2>
          <p className="text-lg mb-8 opacity-90">
            Promoções por tempo limitado com frete grátis e garantia Shopee
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg" className="px-8">
              Ver Mais Ofertas
            </Button>
            <Button variant="outline" size="lg" className="px-8 border-white text-white hover:bg-white hover:text-primary">
              Cadastrar para Alertas
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Offers;

