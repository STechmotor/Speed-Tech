import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, Truck, Shield, Award, ArrowRight } from 'lucide-react';
import ShopeeAffiliateButton from '../components/ShopeeAffiliateButton';

const Home = () => {
  const featuredProducts = [
    {
      id: "kit-suspensao-001",
      name: "Kit Suspensão Esportiva",
      price: "R$ 899,90",
      originalPrice: "R$ 1.299,90",
      image: "/api/placeholder/300/300",
      rating: 4.8,
      reviews: 156,
      discount: "31% OFF"
    },
    {
      id: "escapamento-002",
      name: "Escapamento Esportivo Inox",
      price: "R$ 1.299,90",
      originalPrice: "R$ 1.899,90",
      image: "/api/placeholder/300/300",
      rating: 4.9,
      reviews: 89,
      discount: "32% OFF"
    },
    {
      id: "central-multimidia-003",
      name: "Central Multimídia Android",
      price: "R$ 599,90",
      originalPrice: "R$ 899,90",
      image: "/api/placeholder/300/300",
      rating: 4.7,
      reviews: 234,
      discount: "33% OFF"
    },
    {
      id: "kit-xenon-004",
      name: "Kit Xenon H4 8000K",
      price: "R$ 199,90",
      originalPrice: "R$ 299,90",
      image: "/api/placeholder/300/300",
      rating: 4.6,
      reviews: 312,
      discount: "33% OFF"
    }
  ];

  const categories = [
    {
      name: "Peças de Performance",
      image: "/api/placeholder/200/200",
      count: "500+ produtos"
    },
    {
      name: "Acessórios Automotivos",
      image: "/api/placeholder/200/200",
      count: "800+ produtos"
    },
    {
      name: "Ferramentas",
      image: "/api/placeholder/200/200",
      count: "300+ produtos"
    },
    {
      name: "Eletrônicos Automotivos",
      image: "/api/placeholder/200/200",
      count: "400+ produtos"
    },
    {
      name: "Cuidados Automotivos",
      image: "/api/placeholder/200/200",
      count: "250+ produtos"
    },
    {
      name: "Pneus e Rodas",
      image: "/api/placeholder/200/200",
      count: "600+ produtos"
    }
  ];

  const benefits = [
    {
      icon: <Truck className="h-8 w-8 text-primary" />,
      title: "Frete Grátis",
      description: "Em compras acima de R$ 99 via Shopee"
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Garantia Shopee",
      description: "Proteção total em todas as compras"
    },
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "Produtos Originais",
      description: "Apenas produtos de qualidade certificada"
    },
    {
      icon: <Star className="h-8 w-8 text-primary" />,
      title: "Melhor Avaliação",
      description: "Mais de 10.000 clientes satisfeitos"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Speed Tech
              <span className="text-primary"> Motor Parts</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-300">
              Peças e acessórios automotivos de alta performance
            </p>
            <p className="text-lg mb-8 text-gray-400">
              Parceria oficial com Shopee • Frete grátis • Garantia total
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8 py-3">
                Ver Ofertas
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-3 border-white text-white hover:bg-white hover:text-gray-900">
                Explorar Categorias
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Categorias Populares</h2>
            <p className="text-gray-600 text-lg">Encontre exatamente o que você precisa para seu veículo</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardContent className="p-4 text-center">
                  <div className="w-full h-32 bg-gray-200 rounded-lg mb-4 flex items-center justify-center group-hover:bg-gray-300 transition-colors">
                    <span className="text-gray-500 text-sm">Imagem</span>
                  </div>
                  <h3 className="font-semibold text-sm mb-2">{category.name}</h3>
                  <p className="text-xs text-gray-500">{category.count}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Produtos em Destaque</h2>
            <p className="text-gray-600 text-lg">Os mais vendidos com os melhores preços da Shopee</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow group">
                <CardContent className="p-4">
                  <div className="relative mb-4">
                    <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
                      <span className="text-gray-500">Imagem do Produto</span>
                    </div>
                    <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                      {product.discount}
                    </Badge>
                  </div>
                  <h3 className="font-semibold mb-2 line-clamp-2">{product.name}</h3>
                  <div className="flex items-center mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500 ml-2">({product.reviews})</span>
                  </div>
                  <div className="mb-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-primary">{product.price}</span>
                      <span className="text-sm text-gray-500 line-through">{product.originalPrice}</span>
                    </div>
                  </div>
                  <ShopeeAffiliateButton
                    productId={product.id}
                    productName={product.name}
                    price={product.price}
                    originalPrice={product.originalPrice}
                    source="home_page"
                    campaign="featured_products"
                    showPrice={false}
                    showDiscount={false}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              Ver Todos os Produtos
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Fique por Dentro das Ofertas</h2>
          <p className="text-lg mb-8 opacity-90">
            Receba em primeira mão as melhores promoções e lançamentos
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Seu e-mail"
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <Button variant="secondary" size="lg" className="px-8">
              Cadastrar
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

