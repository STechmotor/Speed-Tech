# Speed Tech Motor Parts - Site de Vendas com Afiliados Shopee

![Speed Tech Logo](src/assets/speed-tech-logo.jpg)

## 🚀 Sobre o Projeto

Site de vendas profissional para a Speed Tech Motor Parts, especializada em peças e acessórios automotivos, com integração completa ao programa de afiliados da Shopee.

## ✨ Características Principais

- 🎨 **Design Responsivo**: Interface moderna e adaptável a todos os dispositivos
- 🛒 **Integração Shopee**: Sistema completo de afiliados com tracking
- 📊 **Analytics**: Rastreamento de cliques e conversões
- ⚡ **Performance**: Build otimizado com Vite e React
- 🔍 **SEO Otimizado**: Meta tags e estrutura semântica
- 🎯 **UX Focada em Conversão**: Interface otimizada para vendas

## 🛠️ Tecnologias Utilizadas

- **React 18** - Framework frontend
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Framework CSS utilitário
- **shadcn/ui** - Componentes UI modernos
- **Lucide React** - Ícones SVG
- **React Router** - Roteamento SPA

## 📁 Estrutura do Projeto

```
speed-tech-site/
├── src/
│   ├── components/          # Componentes reutilizáveis
│   ├── pages/              # Páginas da aplicação
│   ├── lib/                # Utilitários e helpers
│   └── assets/             # Imagens e recursos
├── public/                 # Arquivos públicos
└── dist/                   # Build de produção
```

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+
- npm ou yarn

### Instalação
```bash
# Clone o repositório
git clone [URL_DO_REPOSITORIO]

# Entre no diretório
cd speed-tech-site

# Instale as dependências
npm install

# Execute em modo desenvolvimento
npm run dev

# Acesse http://localhost:5173
```

### Build para Produção
```bash
# Gere o build otimizado
npm run build

# Os arquivos estarão em /dist
```

## 🔗 Sistema de Afiliados

O site inclui um sistema completo de afiliados da Shopee:

- **ID de Afiliado**: SPEEDTECH2025
- **Tracking de Cliques**: Analytics completo
- **UTM Parameters**: Rastreamento de campanhas
- **Links Otimizados**: Redirecionamento inteligente

### Exemplo de Link Gerado
```
https://shopee.com.br/search?keyword=Kit%20Suspensão&affiliate_id=SPEEDTECH2025&utm_source=website&utm_medium=affiliate&utm_campaign=featured_products
```

## 📊 Métricas de Performance

- **Bundle Size**: 306.26 kB (92.11 kB gzipped)
- **Build Time**: ~3.25s
- **Lighthouse Score**: 90+ (Performance, SEO, Accessibility)

## 🎨 Identidade Visual

### Paleta de Cores
- **Speed Tech**: Branco, Laranja (#FF6B35), Cinza Escuro
- **Shopee**: Vermelho (#EE4D2D), Laranja (#FF6200)
- **Complementares**: Azul (#1E40AF), Verde (#059669)

### Tipografia
- **Headings**: Inter (Bold/Semibold)
- **Body**: Inter (Regular/Medium)

## 📱 Páginas Implementadas

1. **Home** - Página principal com hero e produtos em destaque
2. **Categorias** - Listagem de produtos com filtros
3. **Sobre** - História da empresa e valores
4. **Contato** - Formulário e informações de contato

## 🔧 Configuração de Deploy

### Netlify
```toml
[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

### Vercel
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite"
}
```

## 📈 Analytics e Tracking

O site está preparado para integração com:
- Google Analytics 4
- Facebook Pixel
- Google Tag Manager
- Hotjar/Clarity

## 🔒 Segurança

- **HTTPS**: Obrigatório para produção
- **CSP Headers**: Content Security Policy
- **CORS**: Configuração adequada
- **XSS Protection**: Sanitização de inputs

## 📞 Suporte

Para dúvidas ou suporte técnico:
- **Email**: contato@speedtechmotorparts.com.br
- **Telefone**: (11) 9999-9999
- **Documentação**: Ver arquivo `documentacao_speed_tech.pdf`

## 📄 Licença

Este projeto foi desenvolvido para uso exclusivo da Speed Tech Motor Parts.

---

**Desenvolvido com ❤️ por Manus AI**  
**Versão**: 1.0  
**Data**: Junho 2025

